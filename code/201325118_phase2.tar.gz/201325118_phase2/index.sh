#!/bin/bash

python ./code/parallel.py $1 $2
python ./code/search.py $2